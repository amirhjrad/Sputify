#include "sputify.h"


int main()
{
    Sputify sputify;
    sputify.run();
}