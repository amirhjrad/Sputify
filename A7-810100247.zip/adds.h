#ifndef ADDS_H
#define ADDS_H
#include <iostream>
#include <string>
#include <vector>
std::vector<std::string> separateText(std::string text, char seperator);
void checkData(std::string &token, std::vector<std::string>& result);
#endif